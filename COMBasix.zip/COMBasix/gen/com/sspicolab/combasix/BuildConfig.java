/** Automatically generated file. DO NOT MODIFY */
package com.sspicolab.combasix;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}